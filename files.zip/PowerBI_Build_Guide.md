# Sales Performance Dashboard: Power BI Build Guide

Files: `retail_sales.csv` (10,000 rows x 22 cols) · `sales_queries.sql` · `Sales_Performance_Dashboard.xlsx`
Note: the data is a synthetic dataset in the Kaggle "Superstore" schema. To use the real Kaggle file, load it in Step 1 and everything else works unchanged (column names match; rename if yours differ).

## 1. Power Query (Home > Transform data > New Source > Text/CSV)
```m
let
    Source   = Csv.Document(File.Contents("C:\Data\retail_sales.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Types    = Table.TransformColumnTypes(Promoted, {
        {"Order Date", type date}, {"Ship Date", type date}, {"Sales", Currency.Type}, {"Profit", Currency.Type},
        {"Quantity", Int64.Type}, {"Discount", Percentage.Type}, {"Postal Code", type text}}),
    Trimmed  = Table.TransformColumns(Types, {{"Customer Name", Text.Trim, type text}, {"City", Text.Proper, type text}}),
    NoDupes  = Table.Distinct(Trimmed, {"Row ID"}),
    NoNulls  = Table.SelectRows(NoDupes, each [Sales] <> null and [Order Date] <> null),
    ShipDays = Table.AddColumn(NoNulls, "Ship Days", each Duration.Days([Ship Date] - [Order Date]), Int64.Type),
    Band     = Table.AddColumn(ShipDays, "Discount Band", each
                  if [Discount] = 0 then "0%" else if [Discount] <= 0.2 then "1-20%"
                  else if [Discount] <= 0.4 then "21-40%" else "41%+", type text),
    LossFlag = Table.AddColumn(Band, "Loss Making", each [Profit] < 0, type logical)
in
    LossFlag
```
Cleaning checklist: remove duplicates on Row ID · fix data types · trim text · drop null sales/dates · add Ship Days, Discount Band, Loss Making.

## 2. Data model
Name the query `Sales`. Create dimension tables by referencing `Sales` (Reference > keep columns > Remove Duplicates):
- `DimCustomer` (Customer ID, Customer Name, Segment)
- `DimProduct` (Product ID, Product Name, Category, Sub-Category)
- `DimLocation` (Region, State, City)
- `DimDate`: Modeling > New table: `DimDate = ADDCOLUMNS(CALENDAR(DATE(2022,1,1),DATE(2025,12,31)),"Year",YEAR([Date]),"Month No",MONTH([Date]),"Month",FORMAT([Date],"MMM"),"Quarter","Q"&ROUNDUP(MONTH([Date])/3,0))`; mark as date table.
Relationships (single direction, 1:*): DimDate[Date]→Sales[Order Date], DimProduct[Product ID]→Sales[Product ID], DimCustomer[Customer ID]→Sales[Customer ID]. For location, use Sales[Region]/[State] directly or key on City.

## 3. DAX measures (create in a `_Measures` table)
```dax
Total Revenue   = SUM(Sales[Sales])
Total Profit    = SUM(Sales[Profit])
Profit Margin % = DIVIDE([Total Profit], [Total Revenue])
Units Sold      = SUM(Sales[Quantity])
Avg Discount %  = AVERAGE(Sales[Discount])
Revenue PY      = CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(DimDate[Date]))
Revenue YoY %   = DIVIDE([Total Revenue] - [Revenue PY], [Revenue PY])
Profit YoY %    = DIVIDE([Total Profit] - CALCULATE([Total Profit], SAMEPERIODLASTYEAR(DimDate[Date])), CALCULATE([Total Profit], SAMEPERIODLASTYEAR(DimDate[Date])))
Revenue YTD     = TOTALYTD([Total Revenue], DimDate[Date])
Category Rank   = RANKX(ALL(DimProduct[Sub-Category]), [Total Revenue], , DESC, Dense)
Revenue Share % = DIVIDE([Total Revenue], CALCULATE([Total Revenue], ALL(DimProduct)))
Top 3 Share %   = VAR t = TOPN(3, ALL(DimProduct[Sub-Category]), [Total Revenue]) RETURN DIVIDE(CALCULATE([Total Revenue], t), CALCULATE([Total Revenue], ALL(DimProduct)))
Loss Profit     = CALCULATE([Total Profit], Sales[Profit] < 0)
Loss Lines      = CALCULATE(COUNTROWS(Sales), Sales[Profit] < 0)
High-Disc Margin % = CALCULATE([Profit Margin %], Sales[Discount] > 0.2)
```

## 4. Dashboard: 3 pages, 6 KPIs
Slicers (synced): Year, Region, Segment, Category.
**Page 1: Executive Overview.** KPI cards: Total Revenue, Total Profit, Profit Margin %, Units Sold, Avg Discount %, Revenue YoY %. Line chart: revenue + profit by month. Column chart: revenue by year with YoY labels. Donut: revenue by segment.
**Page 2: Product & Discount Analysis.** Bar chart: revenue by Sub-Category sorted (add Revenue Share % and a Top 3 Share % card). Clustered columns: profit by Discount Band (conditional red for negatives). Scatter: Discount (x) vs Profit (y), details = Product Name. Table: Category Rank, Revenue, Profit, Margin.
**Page 3: Regional Performance.** Filled map or bar by Region/State (revenue, profit). Matrix: Region x Category profit with conditional formatting. Top N customers table (Top N filter = 10). Ship Mode vs Ship Days bar.
Theme: dark-blue headers, red for loss, consistent number formats ($#,0 / 0.0%).

## 5. Insights to present (verify against your data)
With the supplied data: top 3 categories (Phones, Chairs, Tables) = **62.4%** of revenue; lines discounted over 20% have negative margins (21-40%: -8.7%, 41%+: -81.1%) and wipe out most of the profit made at 0-20% discounts. Tables and Bookcases lose money overall. Recommendations: cap discounts at about 20% on furniture, review pricing on Tables/Bookcases, and prioritise stock for the top 3 categories.
