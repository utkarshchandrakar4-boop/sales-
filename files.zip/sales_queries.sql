-- Sales Performance Dashboard | SQL layer (ANSI-style; tested on SQLite 3.4x, works on MySQL 8 / PostgreSQL / SQL Server with minor date-function changes)

-- 1. Star schema --------------------------------------------------------------
CREATE TABLE dim_customer AS SELECT DISTINCT "Customer ID" AS customer_id, "Customer Name" AS customer_name, Segment AS segment FROM stg_sales;
CREATE TABLE dim_product  AS SELECT DISTINCT "Product ID" AS product_id, "Product Name" AS product_name, Category AS category, "Sub-Category" AS sub_category FROM stg_sales;
CREATE TABLE dim_location AS SELECT DISTINCT Region AS region, State AS state, City AS city FROM stg_sales;
CREATE TABLE fact_sales AS
SELECT "Row ID" AS row_id, "Order ID" AS order_id, "Order Date" AS order_date, "Ship Date" AS ship_date, "Ship Mode" AS ship_mode,
       "Customer ID" AS customer_id, "Product ID" AS product_id, Region AS region, State AS state, City AS city,
       Sales AS sales, Quantity AS quantity, Discount AS discount, Profit AS profit
FROM stg_sales;

-- Q1. Top categories by revenue and cumulative share (window function)
SELECT sub_category, ROUND(rev,0) AS revenue, ROUND(100.0*rev/SUM(rev) OVER (),1) AS pct_of_total,
       ROUND(100.0*SUM(rev) OVER (ORDER BY rev DESC)/SUM(rev) OVER (),1) AS cumulative_pct
FROM (SELECT p.sub_category, SUM(f.sales) AS rev FROM fact_sales f JOIN dim_product p ON p.product_id=f.product_id GROUP BY p.sub_category) t
ORDER BY rev DESC;

-- Q2. Rank products by revenue and profit within each category (RANK, PARTITION BY)
SELECT * FROM (
  SELECT p.category, p.product_name, ROUND(SUM(f.sales),0) AS revenue, ROUND(SUM(f.profit),0) AS profit,
         RANK() OVER (PARTITION BY p.category ORDER BY SUM(f.sales) DESC) AS revenue_rank,
         RANK() OVER (PARTITION BY p.category ORDER BY SUM(f.profit) DESC) AS profit_rank
  FROM fact_sales f JOIN dim_product p ON p.product_id=f.product_id
  GROUP BY p.category, p.product_name) x
WHERE revenue_rank<=3 ORDER BY category, revenue_rank;

-- Q3. Rank regions by revenue and profit margin
SELECT region, ROUND(SUM(sales),0) AS revenue, ROUND(SUM(profit),0) AS profit,
       ROUND(100.0*SUM(profit)/SUM(sales),1) AS margin_pct,
       DENSE_RANK() OVER (ORDER BY SUM(sales) DESC)  AS revenue_rank,
       DENSE_RANK() OVER (ORDER BY SUM(profit) DESC) AS profit_rank
FROM fact_sales GROUP BY region;

-- Q4. Discount bands vs profit (loss driver)
SELECT CASE WHEN discount=0 THEN '0%' WHEN discount<=0.2 THEN '1-20%' WHEN discount<=0.4 THEN '21-40%' ELSE '41%+' END AS discount_band,
       COUNT(*) AS lines, ROUND(SUM(sales),0) AS revenue, ROUND(SUM(profit),0) AS profit,
       ROUND(100.0*SUM(profit)/SUM(sales),1) AS margin_pct
FROM fact_sales GROUP BY 1 ORDER BY MIN(discount);

-- Q5. Loss-making products: heavily discounted (>20%) lines
SELECT p.sub_category, COUNT(*) AS lines, ROUND(AVG(f.discount)*100,0) AS avg_disc_pct, ROUND(SUM(f.profit),0) AS profit
FROM fact_sales f JOIN dim_product p ON p.product_id=f.product_id
WHERE f.discount>0.2 GROUP BY p.sub_category HAVING SUM(f.profit)<0 ORDER BY profit;

-- Q6. Year-over-year revenue growth (LAG)
SELECT yr, ROUND(rev,0) AS revenue, ROUND(100.0*(rev-LAG(rev) OVER (ORDER BY yr))/LAG(rev) OVER (ORDER BY yr),1) AS yoy_pct
FROM (SELECT SUBSTR(order_date,1,4) AS yr, SUM(sales) AS rev FROM fact_sales GROUP BY 1) t ORDER BY yr;

-- Q7. Monthly revenue with 3-month moving average
SELECT ym, ROUND(rev,0) AS revenue, ROUND(AVG(rev) OVER (ORDER BY ym ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),0) AS ma3
FROM (SELECT SUBSTR(order_date,1,7) AS ym, SUM(sales) AS rev FROM fact_sales GROUP BY 1) t ORDER BY ym;

-- Q8. Top 5 customers per segment (JOIN + ROW_NUMBER)
SELECT * FROM (
  SELECT c.segment, c.customer_name, ROUND(SUM(f.sales),0) AS revenue,
         ROW_NUMBER() OVER (PARTITION BY c.segment ORDER BY SUM(f.sales) DESC) AS rn
  FROM fact_sales f JOIN dim_customer c ON c.customer_id=f.customer_id GROUP BY c.segment, c.customer_id, c.customer_name) t
WHERE rn<=5 ORDER BY segment, rn;
